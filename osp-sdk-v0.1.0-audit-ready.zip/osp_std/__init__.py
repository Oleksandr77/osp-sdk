# OSP Standard Library
# Provides primitive capabilities for robust Agents.
